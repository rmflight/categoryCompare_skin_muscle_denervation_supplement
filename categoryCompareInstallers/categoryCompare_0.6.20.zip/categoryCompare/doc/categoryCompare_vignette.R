### R code from vignette source 'categoryCompare_vignette.Rnw'

###################################################
### code chunk number 1: categoryCompare_vignette.Rnw:63-64
###################################################
options(width=60, continue=" ")


###################################################
### code chunk number 2: setupData
###################################################
library("affy")
library("hgu95av2.db")
library("genefilter")
library("estrogen")
library("limma")

datadir <- system.file("extdata", package = "estrogen")
pd <- read.AnnotatedDataFrame(file.path(datadir,"estrogen.txt"), 
		header = TRUE, sep = "", row.names = 1)
pData(pd)


###################################################
### code chunk number 3: normalize
###################################################
currDir <- getwd()
setwd(datadir)
a <- ReadAffy(filenames=rownames(pData(pd)), phenoData = pd, verbose = TRUE)
eData <- rma(a)
setwd(currDir)


###################################################
### code chunk number 4: eset10
###################################################
e10 <- eData[, eData$time.h == 10]
e10 <- nsFilter(e10, remove.dupEntrez=TRUE, var.filter=FALSE, 
	      feature.exclude="^AFFX")$eset

e10$estrogen <- factor(e10$estrogen)
d10 <- model.matrix(~0 + e10$estrogen)
colnames(d10) <- unique(e10$estrogen)
fit10 <- lmFit(e10, d10)
c10 <- makeContrasts(present - absent, levels=d10)
fit10_2 <- contrasts.fit(fit10, c10)
eB10 <- eBayes(fit10_2)
table10 <- topTable(eB10, number=nrow(e10), p.value=1, adjust.method="BH")
table10$Entrez <- unlist(mget(table10$ID, hgu95av2ENTREZID, ifnotfound=NA))


###################################################
### code chunk number 5: eset48
###################################################
e48 <- eData[, eData$time.h == 48]
e48 <- nsFilter(e48, remove.dupEntrez=TRUE, var.filter=FALSE, 
	      feature.exclude="^AFFX" )$eset

e48$estrogen <- factor(e48$estrogen)
d48 <- model.matrix(~0 + e48$estrogen)
colnames(d48) <- unique(e48$estrogen)
fit48 <- lmFit(e48, d48)
c48 <- makeContrasts(present - absent, levels=d48)
fit48_2 <- contrasts.fit(fit48, c48)
eB48 <- eBayes(fit48_2)
table48 <- topTable(eB48, number=nrow(e48), p.value=1, adjust.method="BH")
table48$Entrez <- unlist(mget(table48$ID, hgu95av2ENTREZID, ifnotfound=NA))

gUniverse <- unique(union(table10$Entrez, table48$Entrez))



###################################################
### code chunk number 6: geneList
###################################################
library("categoryCompare")
library("GO.db")
library("KEGG.db")

# load the saved data with the package
data(ccData)

g10 <- unique(table10$Entrez[table10$adj.P.Val < 0.05])
g48 <- unique(table48$Entrez[table48$adj.P.Val < 0.05])


###################################################
### code chunk number 7: compList
###################################################
list10 <- list(genes=g10, universe=gUniverse, annotation='org.Hs.eg.db')
list48 <- list(genes=g48, universe=gUniverse, annotation='org.Hs.eg.db')

geneLists <- list(T10=list10, T48=list48)
geneLists <- new("ccGeneList", geneLists, ccType=c("BP","KEGG"))
geneLists


###################################################
### code chunk number 8: enrichList
###################################################
enrichLists <- ccEnrich(geneLists)
enrichLists


###################################################
### code chunk number 9: categoryCompare_vignette.Rnw:184-185
###################################################
enrichLists


###################################################
### code chunk number 10: ccOptions
###################################################
ccOpts <- new("ccOptions", listNames=names(geneLists), outType='none')
ccOpts



###################################################
### code chunk number 11: ccResults
###################################################
ccResults <- ccCompare(enrichLists,ccOpts)
ccResults


###################################################
### code chunk number 12: ExamineResultsBP (eval = FALSE)
###################################################
## cw.BP <- ccOutCyt(ccResults$BP,ccOpts)


###################################################
### code chunk number 13: breakEdge (eval = FALSE)
###################################################
## breakEdges(cw.BP,0.2)
## breakEdges(cw.BP,0.4)
## breakEdges(cw.BP,0.6)
## breakEdges(cw.BP,0.8)


###################################################
### code chunk number 14: GOHierarchical (eval = FALSE)
###################################################
## graphType(enrichLists$BP) <- "hierarchical"
## ccResultsBPHier <- ccCompare(enrichLists$BP, ccOpts)


###################################################
### code chunk number 15: categoryCompare_vignette.Rnw:245-246
###################################################
ccResultsBPHier


###################################################
### code chunk number 16: categoryCompare_vignette.Rnw:248-249 (eval = FALSE)
###################################################
## cw.BP2 <- ccOutCyt(ccResultsBPHier, ccOpts, "BPHier")


###################################################
### code chunk number 17: categoryCompare_vignette.Rnw:265-266 (eval = FALSE)
###################################################
## cw.KEGG <- ccOutCyt(ccResults$KEGG,ccOpts)


###################################################
### code chunk number 18: categoryCompare_vignette.Rnw:283-284
###################################################
sessionInfo()


